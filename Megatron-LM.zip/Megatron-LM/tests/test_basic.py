def test_import():
    import megatron

